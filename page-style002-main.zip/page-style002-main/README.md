Exercício de segundo semestre da materia padrões e sitios 2.
Criação de uma página web estilizada usando HTML e CSS.
